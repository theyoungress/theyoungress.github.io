#pragma once
#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "NDGameSave.generated.h"
USTRUCT()
struct FNDActorSave
{
    GENERATED_BODY()
    UPROPERTY() FName Id;
    UPROPERTY() FTransform Transform;
    UPROPERTY() float Health=100;
};
UCLASS()
class NEWDELHIUNDERWORLD_API UNDGameSave : public USaveGame
{
    GENERATED_BODY()
public:
    UPROPERTY() int32 Version=1;
    UPROPERTY() FTransform PlayerTransform;
    UPROPERTY() float Health=100;
    UPROPERTY() float Stamina=100;
    UPROPERTY() int32 Magazine=12;
    UPROPERTY() int32 Reserve=60;
    UPROPERTY() int32 Stage=0;
    UPROPERTY() int32 Money=2500;
    UPROPERTY() TArray<FNDActorSave> Enemies;
};
