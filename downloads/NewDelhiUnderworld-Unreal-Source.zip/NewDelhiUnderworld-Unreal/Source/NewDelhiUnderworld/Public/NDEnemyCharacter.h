#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "NDEnemyCharacter.generated.h"
class UNDHealthComponent;
UCLASS()
class NEWDELHIUNDERWORLD_API ANDEnemyCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ANDEnemyCharacter();
    virtual void Tick(float Delta) override;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UNDHealthComponent> Health;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FName SaveId;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float SightRange=2500;
    void RestoreHealth(float Value);
protected:
    virtual void BeginPlay() override;
    UFUNCTION() void Defeated();
private:
    float LastSeen=-100;
    float LastShot=-100;
    FVector KnownPosition=FVector::ZeroVector;
};
