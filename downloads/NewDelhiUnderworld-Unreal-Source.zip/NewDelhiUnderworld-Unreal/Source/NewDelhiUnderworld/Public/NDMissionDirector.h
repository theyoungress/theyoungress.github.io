#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "NDGameplayRules.h"
#include "NDMissionDirector.generated.h"
UCLASS()
class NEWDELHIUNDERWORLD_API ANDMissionDirector : public AActor
{
    GENERATED_BODY()
public:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) int32 Stage = 0;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) int32 Money = 2500;
    bool Advance(ND::Event Event, const ND::Context& Context);
    FString Objective() const;
};
UENUM(BlueprintType)
enum class ENDPointKind : uint8 { Contact, Ledger, Delivery };
UCLASS()
class NEWDELHIUNDERWORLD_API ANDMissionPoint : public AActor
{
    GENERATED_BODY()
public:
    ANDMissionPoint();
    UPROPERTY(EditAnywhere, BlueprintReadWrite) ENDPointKind Kind = ENDPointKind::Contact;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FText Label;
    bool Interact(APawn* Pawn);
};
