#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "NDHealthComponent.generated.h"
class UDamageType;
class AController;
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FNDDeath);
UCLASS(ClassGroup=(NewDelhi), meta=(BlueprintSpawnableComponent))
class NEWDELHIUNDERWORLD_API UNDHealthComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Health") float Maximum = 100.f;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Health") float Current = 100.f;
    UPROPERTY(BlueprintAssignable) FNDDeath OnDeath;
    UFUNCTION(BlueprintPure) bool IsAlive() const { return Current > 0; }
    void Restore(float Value);
protected:
    virtual void BeginPlay() override;
    UFUNCTION() void Damaged(AActor* Actor, float Damage, const UDamageType* Type, AController* Instigator, AActor* Causer);
};
