#pragma once
#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "InputActionValue.h"
#include "NDPlayerController.generated.h"
class ANDPlayerCharacter;
class UInputMappingContext;
UCLASS()
class NEWDELHIUNDERWORLD_API ANDPlayerController : public APlayerController
{
    GENERATED_BODY()
public:
    virtual void BeginPlay() override;
    virtual void OnPossess(APawn* Pawn) override;
    virtual void SetupInputComponent() override;
    void RecoverPlayer();
    UPROPERTY(BlueprintReadOnly) FString Notice;
    UPROPERTY() TObjectPtr<ANDPlayerCharacter> Protagonist;
    void Tell(const FString& Text);
private:
    UPROPERTY() TObjectPtr<UInputMappingContext> Mapping;
    FTransform Safehouse;
    void Forward(const FInputActionValue& Value);
    void Right(const FInputActionValue& Value);
    void LookX(const FInputActionValue& Value);
    void LookY(const FInputActionValue& Value);
    void Sprint(const FInputActionValue& Value);
    void Aim(const FInputActionValue& Value);
    void Jump(); void Crouch(); void Interact(); void Vehicle(); void Fire(); void Reload(); void Pause(); void Save(); void Load();
};
