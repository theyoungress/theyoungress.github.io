#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/HUD.h"
#include "NDGameMode.generated.h"
UCLASS()
class NEWDELHIUNDERWORLD_API ANDGameMode : public AGameModeBase
{
    GENERATED_BODY()
public: ANDGameMode();
};
UCLASS()
class NEWDELHIUNDERWORLD_API ANDHUD : public AHUD
{
    GENERATED_BODY()
public: virtual void DrawHUD() override;
};
