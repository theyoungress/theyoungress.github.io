#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "NDPlayerCharacter.generated.h"
class UAnimMontage;
class UNDHealthComponent; class UNDWeaponComponent; class USpringArmComponent; class UCameraComponent;
UCLASS()
class NEWDELHIUNDERWORLD_API ANDPlayerCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ANDPlayerCharacter();
    virtual void Tick(float Delta) override;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UNDHealthComponent> Health;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UNDWeaponComponent> Weapon;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<USpringArmComponent> SpringArm;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UCameraComponent> Camera;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Traversal") TObjectPtr<UAnimMontage> VaultMontage;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Movement") float Stamina = 100;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Movement") bool bAiming = false;
    void Sprint(bool Value);
    void Aim(bool Value);
    void JumpOrVault();
    bool IsVaulting() const { return bVaulting; }
    void ResetTraversal();
protected:
    virtual void BeginPlay() override;
    UFUNCTION() void Defeated();
private:
    bool bSprintRequested = false;
    bool bVaulting = false;
    float VaultElapsed = 0;
    float VaultLift = 0;
    FVector VaultStart, VaultEnd;
    bool TryVault();
};
