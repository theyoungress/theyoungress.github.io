#pragma once
#include "CoreMinimal.h"
#include "WheeledVehiclePawn.h"
#include "ChaosVehicleWheel.h"
#include "NDVehiclePawn.generated.h"
class ANDPlayerCharacter;
class USpringArmComponent;
class UCameraComponent;
UCLASS()
class NEWDELHIUNDERWORLD_API UNDFrontWheel : public UChaosVehicleWheel
{
    GENERATED_BODY()
public: UNDFrontWheel();
};
UCLASS()
class NEWDELHIUNDERWORLD_API UNDRearWheel : public UChaosVehicleWheel
{
    GENERATED_BODY()
public: UNDRearWheel();
};
UCLASS()
class NEWDELHIUNDERWORLD_API ANDVehiclePawn : public AWheeledVehiclePawn
{
    GENERATED_BODY()
public:
    ANDVehiclePawn();
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Save") FName SaveId = TEXT("MissionCar");
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<USpringArmComponent> SpringArm;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UCameraComponent> Camera;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<ANDPlayerCharacter> Driver;
    bool Enter(ANDPlayerCharacter* Character);
    bool Exit();
    void Drive(float Value);
    void Steer(float Value);
    void StopInputs();
    float SpeedKmh() const;
};
