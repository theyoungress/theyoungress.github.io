#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace ND {
enum class Stage : std::uint8_t { Contact, Ledger, Vehicle, Delivery, Complete };
enum class Event : std::uint8_t { Talk, Recover, EnterCar, Deliver };
struct State { Stage stage = Stage::Contact; std::int32_t money = 2500; };
struct Context { bool in_range = false; bool guards_clear = false; bool driving = false; bool stopped = false; };
inline bool Advance(State& s, Event event, const Context& c) {
    if (!c.in_range) return false;
    switch (s.stage) {
    case Stage::Contact:
        if (event != Event::Talk) return false;
        s.stage = Stage::Ledger; return true;
    case Stage::Ledger:
        if (event != Event::Recover || !c.guards_clear) return false;
        s.stage = c.driving ? Stage::Delivery : Stage::Vehicle; return true;
    case Stage::Vehicle:
        if (event != Event::EnterCar || !c.driving) return false;
        s.stage = Stage::Delivery; return true;
    case Stage::Delivery:
        if (event != Event::Deliver || !c.driving || !c.stopped) return false;
        s.stage = Stage::Complete; s.money += 5000; return true;
    case Stage::Complete: return false;
    }
    return false;
}
inline int Reload(int& magazine, int& reserve, int capacity = 12) {
    if (magazine < 0 || reserve < 0 || capacity < 1 || magazine >= capacity) return 0;
    const int transfer = std::min(capacity - magazine, reserve);
    magazine += transfer; reserve -= transfer; return transfer;
}
inline bool ValidPosition(double x, double y, double z) { return std::isfinite(x) && std::isfinite(y) && std::isfinite(z) && std::abs(x) < 1000000 && std::abs(y) < 1000000 && std::abs(z) < 1000000; }
}
