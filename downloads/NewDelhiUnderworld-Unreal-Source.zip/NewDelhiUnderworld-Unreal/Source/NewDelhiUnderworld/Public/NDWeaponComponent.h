#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "NDWeaponComponent.generated.h"
class USoundBase;
class UAnimMontage;
UCLASS(ClassGroup=(NewDelhi), meta=(BlueprintSpawnableComponent))
class NEWDELHIUNDERWORLD_API UNDWeaponComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UPROPERTY(EditDefaultsOnly, Category="Weapon") float Damage = 34.f;
    UPROPERTY(EditDefaultsOnly, Category="Weapon") float Range = 15000.f;
    UPROPERTY(EditDefaultsOnly, Category="Weapon") float ShotInterval = .22f;
    UPROPERTY(EditDefaultsOnly, Category="Weapon") float ReloadSeconds = 1.25f;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Weapon") int32 Magazine = 12;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Weapon") int32 Reserve = 60;
    UPROPERTY(EditDefaultsOnly, Category="Presentation") TObjectPtr<USoundBase> ShotSound;
    UPROPERTY(EditDefaultsOnly, Category="Presentation") TObjectPtr<USoundBase> ReloadSound;
    UPROPERTY(EditDefaultsOnly, Category="Presentation") TObjectPtr<UAnimMontage> FireMontage;
    UPROPERTY(EditDefaultsOnly, Category="Presentation") TObjectPtr<UAnimMontage> ReloadMontage;
    bool Fire();
    void Reload();
    bool IsReloading() const;
    void ResetTransient();
private:
    float LastShot = -100.f;
    FTimerHandle ReloadTimer;
    void FinishReload();
};
