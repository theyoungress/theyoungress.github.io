#include "NDGameMode.h"
#include "NDPlayerController.h"
#include "NDPlayerCharacter.h"
#include "NDHealthComponent.h"
#include "NDWeaponComponent.h"
#include "NDMissionDirector.h"
#include "NDVehiclePawn.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "EngineUtils.h"
ANDGameMode::ANDGameMode() { DefaultPawnClass=ANDPlayerCharacter::StaticClass(); PlayerControllerClass=ANDPlayerController::StaticClass(); HUDClass=ANDHUD::StaticClass(); }
void ANDHUD::DrawHUD()
{
    Super::DrawHUD(); if(!Canvas) return;
    auto* PC=Cast<ANDPlayerController>(GetOwningPlayerController()); if(!PC) return;
    const float W=Canvas->SizeX,H=Canvas->SizeY;
    DrawRect(FLinearColor(0,0,0,.65f),20,20,FMath::Min(W-40,680.f),110);
    DrawText(TEXT("NEW DELHI UNDERWORLD | DEVELOPMENT"),FColor(235,191,99),34,28,GEngine->GetMediumFont());
    for(TActorIterator<ANDMissionDirector> It(GetWorld());It;++It) { DrawText(It->Objective(),FColor::White,34,56,GEngine->GetSmallFont()); DrawText(FString::Printf(TEXT("Rs %d"),It->Money),FColor::White,34,83); break; }
    if(PC->Protagonist) { auto* C=PC->Protagonist.Get(); DrawText(FString::Printf(TEXT("Health %.0f   Stamina %.0f   Ammo %d / %d%s"),C->Health->Current,C->Stamina,C->Weapon->Magazine,C->Weapon->Reserve,C->Weapon->IsReloading()?TEXT("  Reloading"):TEXT("")),FColor::White,24,H-90); }
    DrawText(PC->Notice,FColor(235,191,99),24,H-65);
    DrawText(TEXT("WASD move | Mouse look | Shift sprint | Ctrl crouch | Space jump/vault | E objective | F vehicle | RMB aim | LMB fire | R reload | F5 save | F9 load | Esc pause"),FColor::White,24,H-35,GEngine->GetSmallFont(),.85f);
    if(auto* Car=Cast<ANDVehiclePawn>(PC->GetPawn())) DrawText(FString::Printf(TEXT("%.0f km/h"),Car->SpeedKmh()),FColor::White,W-160,H-120);
    else { DrawLine(W/2-5,H/2,W/2+5,H/2,FLinearColor::White); DrawLine(W/2,H/2-5,W/2,H/2+5,FLinearColor::White); }
    if(PC->IsPaused()) { DrawRect(FLinearColor(0,0,0,.65f),0,0,W,H); DrawText(TEXT("PAUSED - Escape to resume"),FColor::White,W/2-150,H/2,GEngine->GetMediumFont()); }
}
