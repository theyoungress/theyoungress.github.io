#include "NDMissionDirector.h"
#include "NDVehiclePawn.h"
#include "NDEnemyCharacter.h"
#include "NDHealthComponent.h"
#include "Components/SceneComponent.h"
#include "EngineUtils.h"
bool ANDMissionDirector::Advance(ND::Event Event,const ND::Context& Context)
{
    ND::State State{static_cast<ND::Stage>(Stage),Money};
    if(!ND::Advance(State,Event,Context)) return false;
    Stage=static_cast<int32>(State.stage); Money=State.money; return true;
}
FString ANDMissionDirector::Objective() const
{
    static const TCHAR* Text[]={TEXT("Find the contact at Nai Sarak"),TEXT("Defeat the guards and recover the ledger"),TEXT("Get into the getaway car"),TEXT("Bring the ledger to the safehouse and stop"),TEXT("Delivery complete. Rs 5,000 received.")};
    return Text[FMath::Clamp(Stage,0,4)];
}
ANDMissionPoint::ANDMissionPoint() { RootComponent=CreateDefaultSubobject<USceneComponent>(TEXT("Root")); }
bool ANDMissionPoint::Interact(APawn* Pawn)
{
    if(!Pawn) return false;
    ANDMissionDirector* Director=nullptr; for(TActorIterator<ANDMissionDirector> It(GetWorld());It;++It) { Director=*It; break; }
    if(!Director) return false;
    auto* Car=Cast<ANDVehiclePawn>(Pawn);
    ND::Context Context;
    Context.in_range=FVector::Dist(Pawn->GetActorLocation(),GetActorLocation())<(Kind==ENDPointKind::Delivery ? 700 : 250);
    Context.driving=Car!=nullptr; Context.stopped=Car && Car->SpeedKmh()<2; Context.guards_clear=true;
    for(TActorIterator<ANDEnemyCharacter> It(GetWorld());It;++It) if(It->Health->IsAlive()) { Context.guards_clear=false; break; }
    return Director->Advance(Kind==ENDPointKind::Contact ? ND::Event::Talk : Kind==ENDPointKind::Ledger ? ND::Event::Recover : ND::Event::Deliver,Context);
}
