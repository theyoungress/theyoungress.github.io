#include "Modules/ModuleManager.h"
IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, NewDelhiUnderworld, "NewDelhiUnderworld");
