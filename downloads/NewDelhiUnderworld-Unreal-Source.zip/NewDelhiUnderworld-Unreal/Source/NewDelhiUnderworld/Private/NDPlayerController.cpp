#include "NDPlayerController.h"
#include "NDPlayerCharacter.h"
#include "NDVehiclePawn.h"
#include "NDEnemyCharacter.h"
#include "NDHealthComponent.h"
#include "NDWeaponComponent.h"
#include "NDMissionDirector.h"
#include "NDGameSave.h"
#include "NDGameplayRules.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputMappingContext.h"
#include "InputModifiers.h"
#include "InputAction.h"
#include "Engine/LocalPlayer.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/CharacterMovementComponent.h"
namespace
{
ANDMissionDirector* Mission(UWorld* World) { for(TActorIterator<ANDMissionDirector> It(World);It;++It) return *It; return nullptr; }
bool ValidTransform(const FTransform& T) { const auto P=T.GetLocation(); return !T.ContainsNaN() && T.GetRotation().IsNormalized() && T.GetScale3D().Equals(FVector::OneVector,.01f) && ND::ValidPosition(P.X,P.Y,P.Z); }
constexpr const TCHAR* Slot=TEXT("NewDelhiUnderworld");
}
void ANDPlayerController::OnPossess(APawn* Pawn)
{
    Super::OnPossess(Pawn);
    if(auto* Character=Cast<ANDPlayerCharacter>(Pawn))
    {
        if(!Protagonist) Safehouse=Character->GetActorTransform();
        Protagonist=Character;
    }
}
void ANDPlayerController::BeginPlay()
{
    Super::BeginPlay(); Protagonist=Cast<ANDPlayerCharacter>(GetPawn()); if(Protagonist) Safehouse=Protagonist->GetActorTransform();
    if(auto* Local=GetLocalPlayer()) if(auto* Input=Local->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>()) if(Mapping) Input->AddMappingContext(Mapping,0);
    SetInputMode(FInputModeGameOnly()); bShowMouseCursor=false;
}
void ANDPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent(); auto* Input=CastChecked<UEnhancedInputComponent>(InputComponent);
    Mapping=NewObject<UInputMappingContext>(this);
    auto Axis=[&](const TCHAR* Name,FKey Positive,FKey Negative,auto Method)
    {
        auto* Action=NewObject<UInputAction>(Mapping,Name); Action->ValueType=EInputActionValueType::Axis1D;
        Mapping->MapKey(Action,Positive);
        if(Negative.IsValid()) Mapping->MapKey(Action,Negative).Modifiers.Add(NewObject<UInputModifierNegate>(Mapping));
        Input->BindAction(Action,ETriggerEvent::Triggered,this,Method); Input->BindAction(Action,ETriggerEvent::Completed,this,Method);
    };
    Axis(TEXT("Forward"),EKeys::W,EKeys::S,&ANDPlayerController::Forward);
    Axis(TEXT("Right"),EKeys::D,EKeys::A,&ANDPlayerController::Right);
    Axis(TEXT("LookX"),EKeys::MouseX,FKey(),&ANDPlayerController::LookX);
    Axis(TEXT("LookY"),EKeys::MouseY,FKey(),&ANDPlayerController::LookY);
    Axis(TEXT("Sprint"),EKeys::LeftShift,FKey(),&ANDPlayerController::Sprint);
    Axis(TEXT("Aim"),EKeys::RightMouseButton,FKey(),&ANDPlayerController::Aim);
    auto Button=[&](const TCHAR* Name,FKey Key,auto Method,bool Paused=false)
    {
        auto* Action=NewObject<UInputAction>(Mapping,Name); Action->ValueType=EInputActionValueType::Boolean; Action->bTriggerWhenPaused=Paused;
        Mapping->MapKey(Action,Key); Input->BindAction(Action,ETriggerEvent::Started,this,Method);
    };
    Button(TEXT("Jump"),EKeys::SpaceBar,&ANDPlayerController::Jump); Button(TEXT("Crouch"),EKeys::LeftControl,&ANDPlayerController::Crouch);
    Button(TEXT("Interact"),EKeys::E,&ANDPlayerController::Interact); Button(TEXT("Vehicle"),EKeys::F,&ANDPlayerController::Vehicle);
    Button(TEXT("Fire"),EKeys::LeftMouseButton,&ANDPlayerController::Fire); Button(TEXT("Reload"),EKeys::R,&ANDPlayerController::Reload);
    Button(TEXT("Save"),EKeys::F5,&ANDPlayerController::Save); Button(TEXT("Load"),EKeys::F9,&ANDPlayerController::Load);
    Button(TEXT("Pause"),EKeys::Escape,&ANDPlayerController::Pause,true);
    if(auto* Local=GetLocalPlayer()) if(auto* Subsystem=Local->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>()) Subsystem->AddMappingContext(Mapping,0);
}
void ANDPlayerController::Forward(const FInputActionValue& V)
{
    if(auto* Car=Cast<ANDVehiclePawn>(GetPawn())) { Car->Drive(V.Get<float>()); return; }
    if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) if(!C->IsVaulting()) C->AddMovementInput(FRotationMatrix(FRotator(0,GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::X),V.Get<float>());
}
void ANDPlayerController::Right(const FInputActionValue& V)
{
    if(auto* Car=Cast<ANDVehiclePawn>(GetPawn())) { Car->Steer(V.Get<float>()); return; }
    if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) if(!C->IsVaulting()) C->AddMovementInput(FRotationMatrix(FRotator(0,GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::Y),V.Get<float>());
}
void ANDPlayerController::LookX(const FInputActionValue& V) { AddYawInput(V.Get<float>()); }
void ANDPlayerController::LookY(const FInputActionValue& V) { AddPitchInput(-V.Get<float>()); }
void ANDPlayerController::Sprint(const FInputActionValue& V) { if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) C->Sprint(V.Get<float>()>.5f); }
void ANDPlayerController::Aim(const FInputActionValue& V) { if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) C->Aim(V.Get<float>()>.5f); }
void ANDPlayerController::Jump() { if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) C->JumpOrVault(); }
void ANDPlayerController::Crouch() { if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) { if(C->bIsCrouched) C->UnCrouch(); else C->Crouch(); } }
void ANDPlayerController::Fire() { if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) C->Weapon->Fire(); }
void ANDPlayerController::Reload() { if(auto* C=Cast<ANDPlayerCharacter>(GetPawn())) C->Weapon->Reload(); }
void ANDPlayerController::Tell(const FString& Text) { Notice=Text; }
void ANDPlayerController::Interact()
{
    for(TActorIterator<ANDMissionPoint> It(GetWorld());It;++It) if(It->Interact(GetPawn())) { if(auto* M=Mission(GetWorld())) Tell(M->Objective()); return; }
    Tell(TEXT("Move closer to the active objective. The ledger requires all guards defeated; delivery requires a stopped car."));
}
void ANDPlayerController::Vehicle()
{
    if(auto* Car=Cast<ANDVehiclePawn>(GetPawn())) { Tell(Car->Exit() ? TEXT("On foot") : TEXT("Stop the car and leave space beside a door.")); return; }
    auto* C=Cast<ANDPlayerCharacter>(GetPawn()); if(!C) return;
    ANDVehiclePawn* Closest=nullptr; float Distance=400;
    for(TActorIterator<ANDVehiclePawn> It(GetWorld());It;++It) { const float D=FVector::Dist(C->GetActorLocation(),It->GetActorLocation()); if(D<Distance) { Distance=D; Closest=*It; } }
    if(Closest && Closest->Enter(C)) { if(auto* M=Mission(GetWorld())) { ND::Context Context; Context.in_range=true; Context.driving=true; M->Advance(ND::Event::EnterCar,Context); } Tell(TEXT("W/S drive and brake, A/D steer, F exit when stopped.")); }
    else Tell(TEXT("Move closer to an empty vehicle."));
}
void ANDPlayerController::Pause()
{
    const bool Paused=!IsPaused(); SetPause(Paused);
    if(Protagonist) { Protagonist->Sprint(false); Protagonist->Aim(false); }
    if(auto* Car=Cast<ANDVehiclePawn>(GetPawn())) Car->StopInputs();
}
void ANDPlayerController::RecoverPlayer()
{
    if(!Protagonist) return;
    if(auto* Car=Cast<ANDVehiclePawn>(GetPawn())) { Car->StopInputs(); Car->Driver=nullptr; Possess(Protagonist); }
    Protagonist->SetActorHiddenInGame(false); Protagonist->SetActorEnableCollision(true);
    Protagonist->Weapon->ResetTransient(); Protagonist->ResetTraversal(); Protagonist->SetActorTransform(Safehouse);
    Protagonist->Health->Restore(100); Protagonist->Stamina=100; Protagonist->Aim(false); Protagonist->Sprint(false); Tell(TEXT("Recovered at your starting point."));
}
void ANDPlayerController::Save()
{
    if(!Protagonist || GetPawn()!=Protagonist || Protagonist->IsVaulting() || !Protagonist->GetCharacterMovement()->IsMovingOnGround()) { Tell(TEXT("Save while standing on foot.")); return; }
    auto* M=Mission(GetWorld()); if(!M) { Tell(TEXT("This level has no mission director.")); return; }
    auto* Data=Cast<UNDGameSave>(UGameplayStatics::CreateSaveGameObject(UNDGameSave::StaticClass()));
    Data->PlayerTransform=Protagonist->GetActorTransform(); Data->Health=Protagonist->Health->Current; Data->Stamina=Protagonist->Stamina;
    Data->Magazine=Protagonist->Weapon->Magazine; Data->Reserve=Protagonist->Weapon->Reserve; Data->Stage=M->Stage; Data->Money=M->Money;
    TSet<FName> Seen;
    for(TActorIterator<ANDEnemyCharacter> It(GetWorld());It;++It)
    {
        if(It->SaveId.IsNone() || Seen.Contains(It->SaveId)) { Tell(TEXT("Save failed: enemies need unique SaveId values.")); return; }
        Seen.Add(It->SaveId); FNDActorSave Row; Row.Id=It->SaveId; Row.Transform=It->GetActorTransform(); Row.Health=It->Health->Current; Data->Enemies.Add(Row);
    }
    Tell(UGameplayStatics::SaveGameToSlot(Data,Slot,0) ? TEXT("Saved. Vehicles reset on a new session.") : TEXT("Save failed."));
}
void ANDPlayerController::Load()
{
    if(!Protagonist || GetPawn()!=Protagonist) { Tell(TEXT("Exit the vehicle before loading.")); return; }
    auto* Data=Cast<UNDGameSave>(UGameplayStatics::LoadGameFromSlot(Slot,0)); auto* M=Mission(GetWorld());
    if(!Data || !M || Data->Version!=1 || !ValidTransform(Data->PlayerTransform) || !FMath::IsFinite(Data->Health) || Data->Health<=0 || Data->Health>100 || !FMath::IsFinite(Data->Stamina) || Data->Stamina<0 || Data->Stamina>100 || Data->Magazine<0 || Data->Magazine>12 || Data->Reserve<0 || Data->Reserve>10000 || Data->Stage<0 || Data->Stage>4 || Data->Money<0 || Data->Money>10000000) { Tell(TEXT("No compatible, valid save found.")); return; }
    TMap<FName,ANDEnemyCharacter*> Enemies;
    for(TActorIterator<ANDEnemyCharacter> It(GetWorld());It;++It) { if(It->SaveId.IsNone() || Enemies.Contains(It->SaveId)) { Tell(TEXT("Level has invalid enemy IDs.")); return; } Enemies.Add(It->SaveId,*It); }
    TSet<FName> Seen;
    if(Data->Enemies.Num()!=Enemies.Num()) { Tell(TEXT("Save belongs to a different level revision.")); return; }
    for(const auto& Row:Data->Enemies) { if(!Enemies.Contains(Row.Id) || Seen.Contains(Row.Id) || !ValidTransform(Row.Transform) || !FMath::IsFinite(Row.Health) || Row.Health<0 || Row.Health>100) { Tell(TEXT("Invalid saved enemy state.")); return; } Seen.Add(Row.Id); }
    FVector Destination=Data->PlayerTransform.GetLocation(); const FRotator Rotation=Data->PlayerTransform.Rotator();
    if(!GetWorld()->FindTeleportSpot(Protagonist,Destination,Rotation)) { Tell(TEXT("Saved position is obstructed.")); return; }
    Protagonist->Weapon->ResetTransient(); Protagonist->ResetTraversal(); Protagonist->Aim(false); Protagonist->Sprint(false);
    Protagonist->SetActorLocationAndRotation(Destination,Rotation); Protagonist->Health->Restore(Data->Health); Protagonist->Stamina=Data->Stamina;
    Protagonist->Weapon->Magazine=Data->Magazine; Protagonist->Weapon->Reserve=Data->Reserve; M->Stage=Data->Stage; M->Money=Data->Money;
    for(const auto& Row:Data->Enemies) { auto* Enemy=Enemies[Row.Id]; Enemy->SetActorTransform(Row.Transform); Enemy->RestoreHealth(Row.Health); }
    Tell(TEXT("Loaded."));
}
