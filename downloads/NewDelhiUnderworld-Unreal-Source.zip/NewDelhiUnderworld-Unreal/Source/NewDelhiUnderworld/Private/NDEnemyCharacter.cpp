#include "NDEnemyCharacter.h"
#include "Components/CapsuleComponent.h"
#include "NDVehiclePawn.h"
#include "NDPlayerCharacter.h"
#include "NDHealthComponent.h"
#include "AIController.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/DamageType.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
ANDEnemyCharacter::ANDEnemyCharacter()
{
    GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Visibility,ECR_Block);
    PrimaryActorTick.bCanEverTick=true; PrimaryActorTick.TickInterval=.15f;
    AIControllerClass=AAIController::StaticClass(); AutoPossessAI=EAutoPossessAI::PlacedInWorldOrSpawned;
    Health=CreateDefaultSubobject<UNDHealthComponent>(TEXT("Health")); GetCharacterMovement()->MaxWalkSpeed=320;
}
void ANDEnemyCharacter::BeginPlay() { Super::BeginPlay(); Health->OnDeath.AddDynamic(this,&ANDEnemyCharacter::Defeated); }
void ANDEnemyCharacter::Defeated() { GetCharacterMovement()->DisableMovement(); if(auto* AI=Cast<AAIController>(GetController())) AI->StopMovement(); SetActorHiddenInGame(true); SetActorEnableCollision(false); }
void ANDEnemyCharacter::RestoreHealth(float Value)
{
    Health->Restore(Value); LastSeen=-100; LastShot=-100;
    SetActorHiddenInGame(!Health->IsAlive()); SetActorEnableCollision(Health->IsAlive());
    if(Health->IsAlive()) GetCharacterMovement()->SetMovementMode(MOVE_Walking); else Defeated();
}
void ANDEnemyCharacter::Tick(float Delta)
{
    Super::Tick(Delta); if(!Health->IsAlive()) return;
    auto* AI=Cast<AAIController>(GetController()); APawn* Player=UGameplayStatics::GetPlayerPawn(this,0); if(!AI || !Player) return;
    const float Now=GetWorld()->GetTimeSeconds();
    const bool Visible=FVector::Dist(GetActorLocation(),Player->GetActorLocation())<SightRange && AI->LineOfSightTo(Player);
    if(Visible) { LastSeen=Now; KnownPosition=Player->GetActorLocation(); }
    if(Now-LastSeen>8) { AI->StopMovement(); return; }
    AI->MoveToLocation(KnownPosition,550,false,true);
    if(Visible && Now-LastShot>1.65f)
    {
        LastShot=Now; SetActorRotation(FRotator(0,(KnownPosition-GetActorLocation()).Rotation().Yaw,0));
        FHitResult Hit; FCollisionQueryParams Params(SCENE_QUERY_STAT(NDEnemyShot),false,this);
        const FVector Muzzle=GetActorLocation()+FVector(0,0,55);
        GetWorld()->LineTraceSingleByChannel(Hit,Muzzle,Player->GetActorLocation(),ECC_Visibility,Params);
        if(Hit.GetActor()==Player)
        {
            AActor* Victim=Player;
            if(auto* Car=Cast<ANDVehiclePawn>(Player)) if(Car->Driver) Victim=Car->Driver;
            UGameplayStatics::ApplyPointDamage(Victim,7,(KnownPosition-Muzzle).GetSafeNormal(),Hit,AI,this,UDamageType::StaticClass());
        }
    }
}
