#include "NDPlayerCharacter.h"
#include "NDHealthComponent.h"
#include "NDWeaponComponent.h"
#include "NDPlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
ANDPlayerCharacter::ANDPlayerCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCapsuleComponent()->InitCapsuleSize(34, 88);
    GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Visibility,ECR_Block);
    GetCharacterMovement()->GetNavAgentPropertiesRef().bCanCrouch = true;
    GetCharacterMovement()->MaxWalkSpeed = 420;
    GetCharacterMovement()->MaxWalkSpeedCrouched = 180;
    GetCharacterMovement()->JumpZVelocity = 600;
    GetCharacterMovement()->BrakingDecelerationWalking = 1800;
    GetCharacterMovement()->bOrientRotationToMovement = true;
    GetCharacterMovement()->RotationRate = FRotator(0, 540, 0);
    bUseControllerRotationYaw = false;
    GetMesh()->SetRelativeLocation(FVector(0,0,-88));
    GetMesh()->SetRelativeRotation(FRotator(0,-90,0));
    SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraArm"));
    SpringArm->SetupAttachment(RootComponent); SpringArm->TargetArmLength = 340;
    SpringArm->SocketOffset = FVector(0,50,70); SpringArm->bUsePawnControlRotation = true;
    SpringArm->bEnableCameraLag = true; SpringArm->CameraLagSpeed = 14; SpringArm->ProbeSize = 15;
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera")); Camera->SetupAttachment(SpringArm); Camera->FieldOfView = 78;
    Health = CreateDefaultSubobject<UNDHealthComponent>(TEXT("Health"));
    Weapon = CreateDefaultSubobject<UNDWeaponComponent>(TEXT("Weapon"));
}
void ANDPlayerCharacter::BeginPlay()
{
    Super::BeginPlay(); Health->OnDeath.AddDynamic(this, &ANDPlayerCharacter::Defeated);
    if (!GetMesh()->GetSkeletalMeshAsset()) UE_LOG(LogTemp, Error, TEXT("Ayan has no skeletal mesh. Assign licensed character and animation assets before playtesting."));
}
void ANDPlayerCharacter::Sprint(bool Value) { bSprintRequested = Value; }
void ANDPlayerCharacter::Aim(bool Value) { bAiming = Value; bUseControllerRotationYaw = Value; GetCharacterMovement()->bOrientRotationToMovement = !Value; }
void ANDPlayerCharacter::Tick(float Delta)
{
    Super::Tick(Delta);
    if (!IsPlayerControlled()) return;
    const bool Running = bSprintRequested && !bAiming && !bIsCrouched && Stamina > 1 && GetVelocity().Size2D() > 20;
    Stamina = FMath::Clamp(Stamina + Delta*(Running ? -17.f : 22.f), 0.f, 100.f);
    GetCharacterMovement()->MaxWalkSpeed = bAiming ? 260 : (Running ? 750 : 420);
    SpringArm->TargetArmLength = FMath::FInterpTo(SpringArm->TargetArmLength, bAiming ? 180.f : 340.f, Delta, 9);
    Camera->FieldOfView = FMath::FInterpTo(Camera->FieldOfView, bAiming ? 58.f : 78.f, Delta, 9);
    if (!bVaulting) return;
    VaultElapsed += Delta;
    const float T = FMath::Clamp(VaultElapsed/.7f, 0.f, 1.f);
    const float Travel = FMath::SmoothStep(.22f,.78f,T);
    const float Lift = FMath::SmoothStep(0.f,.22f,T) * (1.f-FMath::SmoothStep(.78f,1.f,T));
    FVector Next = FMath::Lerp(VaultStart,VaultEnd,Travel) + FVector(0,0,Lift*VaultLift);
    FHitResult Hit;
    SetActorLocation(Next,true,&Hit,ETeleportType::None);
    if (Hit.bBlockingHit || T >= 1) ResetTraversal();
}
void ANDPlayerCharacter::ResetTraversal()
{
    bVaulting = false; VaultElapsed = 0;
    GetCharacterMovement()->SetMovementMode(MOVE_Walking);
    GetCharacterMovement()->StopMovementImmediately();
}
void ANDPlayerCharacter::JumpOrVault()
{
    if (bVaulting || bIsCrouched || !GetCharacterMovement()->IsMovingOnGround()) return;
    if (!TryVault()) Jump();
}
bool ANDPlayerCharacter::TryVault()
{
    const float Half = GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
    const FVector Feet = GetActorLocation()-FVector(0,0,Half);
    const FVector Forward = FRotationMatrix(FRotator(0,GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::X);
    FCollisionQueryParams Params(SCENE_QUERY_STAT(NDVault),false,this);
    FHitResult Face,Top,Floor;
    const FVector Start = Feet+FVector(0,0,45);
    if (!GetWorld()->LineTraceSingleByChannel(Face,Start,Start+Forward*130,ECC_Visibility,Params)) return false;
    const FVector Above = Face.ImpactPoint+Forward*15+FVector(0,0,150);
    if (!GetWorld()->LineTraceSingleByChannel(Top,Above,Above-FVector(0,0,180),ECC_Visibility,Params)) return false;
    const float Height = Top.ImpactPoint.Z-Feet.Z;
    if (Height < 35 || Height > 125 || Top.ImpactNormal.Z < .7f) return false;
    FVector End = Feet+Forward*255;
    if (!GetWorld()->LineTraceSingleByChannel(Floor,End+FVector(0,0,180),End-FVector(0,0,120),ECC_Visibility,Params)) return false;
    if (Floor.ImpactPoint.Z > Feet.Z+30 || Floor.ImpactNormal.Z < .7f) return false;
    End = Floor.ImpactPoint+FVector(0,0,Half+3);
    if (GetWorld()->OverlapBlockingTestByChannel(End,FQuat::Identity,ECC_Pawn,FCollisionShape::MakeCapsule(36,Half),Params)) return false;
    VaultStart = GetActorLocation(); VaultEnd = End; VaultLift = Height+35; VaultElapsed = 0; bVaulting = true;
    GetCharacterMovement()->SetMovementMode(MOVE_Flying); GetCharacterMovement()->StopMovementImmediately();
    if (VaultMontage) PlayAnimMontage(VaultMontage);
    return true;
}
void ANDPlayerCharacter::Defeated()
{
    if (ANDPlayerController* PC = Cast<ANDPlayerController>(UGameplayStatics::GetPlayerController(this,0))) PC->RecoverPlayer();
}
