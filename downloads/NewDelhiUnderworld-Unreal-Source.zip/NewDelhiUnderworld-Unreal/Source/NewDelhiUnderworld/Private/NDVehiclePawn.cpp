#include "NDVehiclePawn.h"
#include "NDPlayerCharacter.h"
#include "NDWeaponComponent.h"
#include "ChaosWheeledVehicleMovementComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
UNDFrontWheel::UNDFrontWheel() { WheelRadius=32; WheelWidth=20; MaxSteerAngle=35; AxleType=EAxleType::Front; bAffectedByEngine=false; }
UNDRearWheel::UNDRearWheel() { WheelRadius=32; WheelWidth=20; MaxSteerAngle=0; AxleType=EAxleType::Rear; bAffectedByEngine=true; bAffectedByHandbrake=true; }
ANDVehiclePawn::ANDVehiclePawn()
{
    GetMesh()->SetCollisionProfileName(TEXT("Vehicle"));
    SpringArm=CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraArm")); SpringArm->SetupAttachment(GetMesh());
    SpringArm->TargetArmLength=650; SpringArm->SocketOffset=FVector(0,0,180); SpringArm->bUsePawnControlRotation=true;
    Camera=CreateDefaultSubobject<UCameraComponent>(TEXT("Camera")); Camera->SetupAttachment(SpringArm); Camera->FieldOfView=85;
    if (auto* Move=Cast<UChaosWheeledVehicleMovementComponent>(GetVehicleMovementComponent()))
    {
        Move->WheelSetups.SetNum(4);
        const FName Bones[]={TEXT("Wheel_FL"),TEXT("Wheel_FR"),TEXT("Wheel_RL"),TEXT("Wheel_RR")};
        for(int32 I=0;I<4;++I) { Move->WheelSetups[I].BoneName=Bones[I]; Move->WheelSetups[I].WheelClass=I<2 ? UNDFrontWheel::StaticClass() : UNDRearWheel::StaticClass(); }
    }
}
float ANDVehiclePawn::SpeedKmh() const { return GetVelocity().Size()*0.036f; }
void ANDVehiclePawn::StopInputs() { auto* M=GetVehicleMovementComponent(); M->SetThrottleInput(0); M->SetSteeringInput(0); M->SetBrakeInput(1); }
void ANDVehiclePawn::Steer(float Value) { GetVehicleMovementComponent()->SetSteeringInput(Value); }
void ANDVehiclePawn::Drive(float Value)
{
    auto* M=GetVehicleMovementComponent();
    if(FMath::Abs(Value)<.01f) { M->SetThrottleInput(0); M->SetBrakeInput(0); return; }
    const float Speed=M->GetForwardSpeed();
    if ((Value<0 && Speed>100)||(Value>0 && Speed<-100)) { M->SetThrottleInput(0); M->SetBrakeInput(1); return; }
    M->SetBrakeInput(0);
    if(Value<0 && M->GetCurrentGear()>=0) M->SetTargetGear(-1,true);
    else if(Value>0 && M->GetCurrentGear()<=0) M->SetTargetGear(1,true);
    M->SetThrottleInput(FMath::Abs(Value));
}
bool ANDVehiclePawn::Enter(ANDPlayerCharacter* Character)
{
    if(!Character || Driver || Character->IsVaulting() || FVector::Dist(Character->GetActorLocation(),GetActorLocation())>400) return false;
    AController* PC=Character->GetController(); if(!PC || !PC->IsPlayerController()) return false;
    Driver=Character; Driver->Weapon->ResetTransient(); Driver->Aim(false); Driver->Sprint(false);
    Driver->GetCharacterMovement()->DisableMovement(); Driver->SetActorEnableCollision(false); Driver->SetActorHiddenInGame(true);
    PC->Possess(this); StopInputs(); return true;
}
bool ANDVehiclePawn::Exit()
{
    if(!Driver || SpeedKmh()>7 || !GetController()) return false;
    const float Half=Driver->GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
    FCollisionQueryParams Params(SCENE_QUERY_STAT(NDExit),false,this); Params.AddIgnoredActor(Driver);
    const FVector Offsets[]={GetActorRightVector()*220,-GetActorRightVector()*220,-GetActorForwardVector()*330};
    for(const FVector& Offset:Offsets)
    {
        const FVector Probe=GetActorLocation()+Offset; FHitResult Floor;
        if(!GetWorld()->LineTraceSingleByChannel(Floor,Probe+FVector(0,0,200),Probe-FVector(0,0,300),ECC_Visibility,Params) || Floor.ImpactNormal.Z<.7f) continue;
        const FVector End=Floor.ImpactPoint+FVector(0,0,Half+4);
        if(GetWorld()->OverlapBlockingTestByChannel(End,FQuat::Identity,ECC_Pawn,FCollisionShape::MakeCapsule(36,Half),Params)) continue;
        AController* PC=GetController(); auto* Character=Driver.Get(); Driver=nullptr; StopInputs();
        Character->SetActorLocation(End); Character->SetActorHiddenInGame(false); Character->SetActorEnableCollision(true); Character->ResetTraversal(); PC->Possess(Character); return true;
    }
    return false;
}
