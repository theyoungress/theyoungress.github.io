#include "NDWeaponComponent.h"
#include "GameFramework/DamageType.h"
#include "NDGameplayRules.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Components/SkeletalMeshComponent.h"
#include "TimerManager.h"
#include "Engine/World.h"
bool UNDWeaponComponent::IsReloading() const { return GetWorld()->GetTimerManager().IsTimerActive(ReloadTimer); }
void UNDWeaponComponent::ResetTransient() { GetWorld()->GetTimerManager().ClearTimer(ReloadTimer); LastShot = -100.f; }
bool UNDWeaponComponent::Fire()
{
    ACharacter* Character = Cast<ACharacter>(GetOwner());
    APlayerController* PC = Character ? Cast<APlayerController>(Character->GetController()) : nullptr;
    if (!PC || PC->IsPaused() || IsReloading() || Magazine <= 0 || GetWorld()->GetTimeSeconds() - LastShot < ShotInterval) return false;
    LastShot = GetWorld()->GetTimeSeconds(); --Magazine;
    FVector Eye; FRotator Aim; PC->GetPlayerViewPoint(Eye, Aim);
    FCollisionQueryParams Params(SCENE_QUERY_STAT(NDShot), true, Character);
    FHitResult CameraHit, MuzzleHit;
    FVector Target = Eye + Aim.Vector() * Range;
    if (GetWorld()->LineTraceSingleByChannel(CameraHit, Eye, Target, ECC_Visibility, Params)) Target = CameraHit.ImpactPoint;
    const FVector Muzzle = Character->GetMesh()->DoesSocketExist(TEXT("Muzzle"))
        ? Character->GetMesh()->GetSocketLocation(TEXT("Muzzle")) : Character->GetActorLocation() + FVector(0,0,45);
    // Trace past the camera's surface intersection so endpoint precision cannot miss it.
    if (GetWorld()->LineTraceSingleByChannel(MuzzleHit, Muzzle, Target + (Target-Muzzle).GetSafeNormal()*2.f, ECC_Visibility, Params))
        UGameplayStatics::ApplyPointDamage(MuzzleHit.GetActor(), Damage, (Target-Muzzle).GetSafeNormal(), MuzzleHit, PC, Character, UDamageType::StaticClass());
    if (ShotSound) UGameplayStatics::PlaySoundAtLocation(this, ShotSound, Muzzle);
    if (FireMontage) Character->PlayAnimMontage(FireMontage);
    PC->AddPitchInput(-.25f);
    return true;
}
void UNDWeaponComponent::Reload()
{
    ACharacter* Character = Cast<ACharacter>(GetOwner());
    if (!Character || !Character->IsPlayerControlled() || IsReloading() || Magazine >= 12 || Reserve <= 0) return;
    GetWorld()->GetTimerManager().SetTimer(ReloadTimer, this, &UNDWeaponComponent::FinishReload, ReloadSeconds, false);
    if (ReloadSound) UGameplayStatics::PlaySoundAtLocation(this, ReloadSound, Character->GetActorLocation());
    if (ReloadMontage) Character->PlayAnimMontage(ReloadMontage);
}
void UNDWeaponComponent::FinishReload() { ND::Reload(Magazine, Reserve); }
