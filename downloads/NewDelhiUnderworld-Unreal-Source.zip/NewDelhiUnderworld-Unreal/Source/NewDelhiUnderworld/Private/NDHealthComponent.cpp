#include "NDHealthComponent.h"
#include "GameFramework/Actor.h"
void UNDHealthComponent::BeginPlay()
{
    Super::BeginPlay(); Current = Maximum;
    GetOwner()->OnTakeAnyDamage.AddDynamic(this, &UNDHealthComponent::Damaged);
}
void UNDHealthComponent::Restore(float Value) { Current = FMath::Clamp(Value, 0.f, Maximum); }
void UNDHealthComponent::Damaged(AActor*, float Damage, const UDamageType*, AController*, AActor*)
{
    if (!FMath::IsFinite(Damage) || Damage <= 0 || !IsAlive()) return;
    Current = FMath::Max(0.f, Current - Damage);
    if (!IsAlive()) OnDeath.Broadcast();
}
