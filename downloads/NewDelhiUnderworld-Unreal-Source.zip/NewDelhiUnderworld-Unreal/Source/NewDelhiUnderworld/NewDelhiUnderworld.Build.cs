using UnrealBuildTool;
public class NewDelhiUnderworld : ModuleRules
{
    public NewDelhiUnderworld(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        CppStandard = CppStandardVersion.Cpp20;
        PublicDependencyModuleNames.AddRange(new string[] {
            "Core", "CoreUObject", "Engine", "InputCore", "EnhancedInput",
            "AIModule", "NavigationSystem", "GameplayTasks", "ChaosVehicles",
            "PhysicsCore", "UMG", "Slate", "SlateCore"
        });
    }
}
