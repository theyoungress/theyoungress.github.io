# New Delhi Underworld — Unreal Engine source

**Native UE5 source preview, not a packaged or finished game.** Target: Windows, Unreal Engine **5.4 or later**. This project has not yet been compiled or run inside Unreal. The previous Godot download is a separate older prototype.

This archive contains C++ gameplay and a Windows build workflow. It does **not** contain Epic's engine, a Windows game executable, realistic art packs, animation assets, or an authored Delhi level. Rendering settings enable Lumen, virtual shadows, TSR and Nanite support; they do not create photorealistic content by themselves.

## Open on your Windows PC

1. Extract the ZIP into a writable folder such as `C:\Projects\NewDelhiUnderworld`.
2. Install your Unreal version's supported Visual Studio 2022 C++ game development workload and Windows SDK. In Epic Launcher, install the UE C++ tools/core components. No engine source checkout is required.
3. Double-click **Build-and-Open.cmd**. It detects UE 5.4+ and builds the editor module. The console remains open if compilation fails.
4. Follow [the art setup guide](Docs/ART-SETUP.md), then build and playtest the mission map.

For a custom engine location, use PowerShell from the project folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Tools\Setup-Windows.ps1 -EngineRoot 'D:\Epic Games\UE_5.5' -OpenEditor
```

The example engine path is illustrative; use your installed version. These scripts use a process-local execution policy and do not change your system policy. Keep the Unreal Editor closed while compiling or packaging to avoid locked binaries.

## Current source behavior

- Third-person movement, aim camera, sprint stamina, crouch, jump and swept vault traversal.
- Semiautomatic hitscan combat, cover obstruction checks, magazine/reserve ammunition and timed reload.
- Guards using Unreal line-of-sight checks, navigation, last-seen memory and damage.
- Chaos four-wheel vehicle possession, reverse/braking, chase camera and stopped-only exit with clearance checks.
- Contact → guarded ledger → getaway car → stopped delivery mission, with a one-time Rs 5,000 reward.
- On-foot saves for player, enemy and mission state. Vehicles are **not persisted**; their level transforms reset on a fresh session. Loading requires exiting the car.
- Native development HUD and pause input. Death currently restores the player at the initial spawn; dead guards disappear. Production presentation remains to be authored.

Animations, weapon presentation/audio, character and vehicle tuning, populated streets, weather, traffic, police/wanted systems, multiple districts, shops and the wider requested open world are not completed. This is the first Unreal implementation milestone, not a claim that the full AAA brief is finished.

## Build a playable Windows package

After completing art setup and playtesting:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Tools\Build-Map.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\Tools\Package-Windows.ps1
```

`Build-Map.ps1` validates configured assets and copies your authored environment into `/Game/Maps/NaiSarak`. It refuses to replace an existing mission map. The package command performs an actual Unreal build/cook/stage/archive and checks for the executable. Share the **entire packaged Windows folder**, not just its `.exe`.

## Verification performed here

- 17/17 engine-independent C++ mission, reload and coordinate validation checks passed.
- 9/9 Python manifest validation tests passed.
- Python syntax and project/config structure inspected.
- Native source received static code review and fixes.

**Not run:** UnrealHeaderTool, Unreal C++ compilation, Windows PowerShell scripts, editor Python API execution, asset import/compatibility checks, PIE, Chaos simulation, rendering or packaged Windows execution. Those require the Windows UE installation and real content. Follow [ACCEPTANCE.md](Docs/ACCEPTANCE.md) before calling a build playable.
