# Unreal migration design

The user now requires Unreal Engine and realistic art, superseding the former Godot fallback. Preserve the prior playable build, but make the new source a native C++ UE5 project. No procedural box city or cube characters are part of this renderer/asset pipeline.

The immediate build target remains the same integrated Phase 1 mission. Use UE CharacterMovement, Enhanced Input, spring-arm cameras, Chaos Vehicles, damage components, perception/last-seen memory, mission progression and validated SaveGame data. Keep engine-independent rules testable with the installed C++ compiler. Engine compilation, asset import, rendering and packaged runtime are separate unverified gates.

The visual target requires a properly rigged human character and animation blueprint; a rigged vehicle with wheel bones, physics asset and vehicle animation blueprint; detailed original or licensed Delhi architecture; PBR materials and appropriate LODs. An art manifest supplies actual asset paths. Missing required assets must be reported before a level is generated; do not substitute geometric blocks or pretend that rendering settings create realistic art.

This machine has no Unreal executable, no exposed GPU, roughly 29 GiB free disk, and no access to EpicGames/UnrealEngine through the current GitHub connection. Prepare usable source and asset validation here. A licensed UE5 installation on an adequately provisioned Windows/cloud machine is required to compile and verify the game. Never publish an uncompiled source archive as a playable Unreal game.
