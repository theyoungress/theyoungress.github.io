# Windows / Unreal acceptance record

All checks below are **pending**. Record engine version, GPU, source revision and build logs with results. Standalone C++ tests do not substitute for these checks.

- [ ] Editor module builds with UnrealHeaderTool and the selected UE/MSVC versions.
- [ ] Missing art paths fail map generation; no placeholder level is silently substituted.
- [ ] Imported skeletal meshes, animation Blueprints, vehicle physics and wheel bones validate.
- [ ] Map generation succeeds and preserves the source environment.
- [ ] Game starts with the configured animated human, correctly framed third-person camera and intact environment collision.
- [ ] WASD, mouse look, aim, sprint stamina, crouch, jump and low-obstacle vault work; blocked vaults do not pass through collision.
- [ ] Shots damage guards and the player; walls stop shots from both sides of cover. Reload conserves ammunition, including while entering a car or loading a save.
- [ ] Guards navigate the actual streets, lose contact behind cover and investigate the last known location.
- [ ] Contact → guards → ledger → car → delivery completes. Early/moving/on-foot delivery is rejected. Reward pays once.
- [ ] Car accelerates through gears, brakes, reverses and steers using Chaos. Camera does not clip into walls.
- [ ] Exit rejects moving cars and blocked door locations; a free side allows a safe exit.
- [ ] Player can take damage in the car and recover correctly on foot when defeated.
- [ ] F5 saves on foot and F9 restores mission/player/guard state; missing saves produce a message. Loading during reload/vault clears transient actions. Saves with incompatible IDs are rejected.
- [ ] Esc pauses and resumes from both possession modes without stuck throttle or aim.
- [ ] Lighting, materials, meshes and animation match the supplied Delhi references at target resolution. Profile frame time on the target GPU; no performance/realism claims are made before this review.
- [ ] RunUAT produces the Windows executable and required data. Launch from the packaged directory on a separate Windows account/machine with prerequisites installed and complete the mission again.
