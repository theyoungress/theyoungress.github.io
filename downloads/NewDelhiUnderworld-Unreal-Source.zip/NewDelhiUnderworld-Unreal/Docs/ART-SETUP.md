# Build the Unreal scene using real assets

The reference images establish sunset India Gate lighting, wet evening reflections and dense Old Delhi streets. They are not 3D assets. Obtain or create appropriate meshes, textures, rigs and animation with licenses that permit your intended game distribution. No marketplace content or engine binaries are bundled here.

## 1. Import and prepare an authored environment

Import your detailed Delhi/Indian street environment into this project. Open its map and use real-world centimeters. Model the buildings, shops, signage, cables, road surfaces and small props with appropriate detail, collision and texture density. Avoid enlarged generic block meshes as architecture. Use Nanite where appropriate, proper roughness/normal maps, realistic exposure and restrained Lumen lighting. Dynamic light/weather systems are not yet authored by this source project.

Use a conventional single persistent level for the first mission; streaming/World Partition assembly and external-actor duplication have not been tested by this script. Make sure there is continuous walkable/drivable collision between the contact, ledger and safehouse. Add a **NavMeshBoundsVolume** over the route and encounter area, then build navigation. Configure runtime navigation generation if your asset pack requires it. Save the source map.

## 2. Create three native-derived Blueprints

In Content Browser, create Blueprint Classes using All Classes:

| Blueprint example | Native parent | Required setup |
| --- | --- | --- |
| BP_Ayan | NDPlayerCharacter | Rigged human skeletal mesh, compatible locomotion/aim Animation Blueprint, correct mesh alignment inside capsule |
| BP_GetawayCar | NDVehiclePawn | Rigged car skeletal mesh, valid physics asset, vehicle Animation Blueprint and four Chaos wheel setups |
| BP_Guard | NDEnemyCharacter | Rigged human skeletal mesh, locomotion Animation Blueprint, correct mesh alignment and visible collision |

For Ayan, the default mesh offset is Z=-88 cm and yaw=-90 degrees. For guards, set the equivalent offset to match your skeleton and capsule. Animation Blueprints must read movement speed, crouch and aim state. Assign optional vault/fire/reload montages and shot/reload sounds on the player components. Add an actual weapon mesh and a `Muzzle` socket aligned with it; absent that socket the code uses a functional chest-height shot origin, which is not final weapon presentation.

For the car:

- Configure chassis mass, center of mass and physics bodies for your actual mesh. Enable Simulate Physics on the skeletal mesh and Vehicle collision. Chassis collision must block Visibility, WorldStatic and WorldDynamic.
- Assign wheel bones matching your rig. Native defaults are `Wheel_FL`, `Wheel_FR`, `Wheel_RL`, `Wheel_RR`; change them if necessary. Front wheels steer, rear wheels drive.
- Tune wheel radius/width, suspension, tire friction, engine torque curve, differential, gears and automatic transmission to the actual car. **These depend on the supplied asset; the C++ defaults alone are not an engineered vehicle setup.**
- Use a Chaos vehicle animation instance with wheel-controller animation. Test suspension, steering, forward drive, reverse and braking before the full mission.

The map builder checks native inheritance, presence of skeletal mesh/animation classes, car physics asset and wheel bone existence. It cannot certify retargeting, art quality, collision correctness, torque tuning or animation behavior.

## 3. Configure the manifest

Copy `Content/ArtManifest.example.json` to `Content/ArtManifest.json`. Replace every empty path with a real asset **package path** without `.uasset`, `.umap`, object suffix or `_C`. Example: `/Game/Actors/BP_Ayan`.

- `environment_map`: your saved authored environment.
- `player_blueprint`, `vehicle_blueprint`, `enemy_blueprint`: the three configured Blueprint assets.
- `positions`: replace example coordinates with valid positions in your actual environment. Units are centimeters. Player/guard coordinates are capsule centers (about 90–100 cm above the ground); car coordinates must respect its root/pivot. Objective coordinates should be reachable nearby.
- `enemies`: assign each guard a unique stable ID and position.

The example positions are format examples, not a recreation of Delhi or valid placements for an arbitrary asset pack. Place visible contact/ledger/safehouse props in the authored environment yourself; mission point actors are invisible interaction locations. Contact and ledger interaction radius is 250 cm, delivery radius 700 cm. The ledger requires every placed NDEnemyCharacter to be defeated. Delivery requires the controlled car to be below 2 km/h.

## 4. Generate and test

Close the editor. Run `Tools/Build-Map.ps1` using PowerShell as shown in README. The script loads your source environment, creates `/Game/Maps/NaiSarak`, sets a custom GameMode, places player start, car, mission director, objectives and guards, and saves. Existing destination assets cause an error to protect manual editing; back them up and rename them before rebuilding.

Open `/Game/Maps/NaiSarak` explicitly and press Play. Build navigation again if needed. Run every check in `ACCEPTANCE.md`, adjusting actual assets, collision, animations and placements until they pass. The development HUD shows the objective and input help; a polished diegetic mission presentation is still future work.

If map generation fails after copying the environment, partial destination assets may remain. Inspect the error, back up or rename `/Game/Maps/NaiSarak` and `/Game/NewDelhi/BP_MissionGameMode` if present, fix the cause and retry. The script does not delete these assets automatically.
