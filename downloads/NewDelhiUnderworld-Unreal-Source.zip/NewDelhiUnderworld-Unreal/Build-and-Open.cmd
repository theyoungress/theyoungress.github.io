@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Tools\Setup-Windows.ps1" -OpenEditor
if errorlevel 1 (echo Build failed. Read the error above.)
pause
