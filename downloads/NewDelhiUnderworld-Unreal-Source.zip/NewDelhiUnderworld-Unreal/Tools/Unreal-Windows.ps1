Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Resolve-UnrealEngine([string]$RequestedRoot) {
    $candidates = @()
    if ($RequestedRoot) { $candidates += $RequestedRoot }
    elseif ($env:UE_ROOT) { $candidates += $env:UE_ROOT }
    else {
        $launcher = Join-Path $env:ProgramData 'Epic\UnrealEngineLauncher\LauncherInstalled.dat'
        if (Test-Path $launcher) {
            $installations = (Get-Content -Raw $launcher | ConvertFrom-Json).InstallationList
            $candidates += @($installations | Where-Object { $_.AppName -like 'UE_5.*' } | ForEach-Object { $_.InstallLocation })
        }
        $epic = Join-Path $env:ProgramFiles 'Epic Games'
        if (Test-Path $epic) { $candidates += @(Get-ChildItem $epic -Directory -Filter 'UE_5.*' | ForEach-Object { $_.FullName }) }
    }
    $engines = @($candidates | Select-Object -Unique | ForEach-Object {
        $versionPath = Join-Path $_ 'Engine\Build\Build.version'
        $buildPath = Join-Path $_ 'Engine\Build\BatchFiles\Build.bat'
        if ((Test-Path $versionPath) -and (Test-Path $buildPath)) {
            $v = Get-Content -Raw $versionPath | ConvertFrom-Json
            if ($v.MajorVersion -eq 5 -and $v.MinorVersion -ge 4) {
                [PSCustomObject]@{ Root = $_; Version = [version]("{0}.{1}.{2}" -f $v.MajorVersion,$v.MinorVersion,$v.PatchVersion) }
            }
        }
    } | Sort-Object Version -Descending)
    if ($engines.Count -eq 0) { throw 'UE 5.4 or later was not found. Pass -EngineRoot "D:\Epic Games\UE_5.x". Install the C++ toolchain required by that UE version.' }
    return $engines[0].Root
}
function Invoke-UnrealChecked([string]$Executable, [string[]]$Arguments) {
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Unreal command failed with exit code $LASTEXITCODE. Read the error above; the build was not completed." }
}
