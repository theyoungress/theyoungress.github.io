param([string]$EngineRoot, [string]$OutputDirectory)
. "$PSScriptRoot\Unreal-Windows.ps1"
$engine = Resolve-UnrealEngine $EngineRoot
$projectRoot = Split-Path $PSScriptRoot -Parent
$project = Join-Path $projectRoot 'NewDelhiUnderworld.uproject'
if (!(Test-Path (Join-Path $projectRoot 'Content\Maps\NaiSarak.umap'))) { throw 'No mission map exists. Complete Docs/ART-SETUP.md and Build-Map.ps1 first.' }
if (!$OutputDirectory) { $OutputDirectory = Join-Path $projectRoot 'Packaged' }
Invoke-UnrealChecked (Join-Path $engine 'Engine\Build\BatchFiles\RunUAT.bat') @('BuildCookRun',"-project=$project",'-noP4','-platform=Win64','-clientconfig=Development','-build','-cook','-map=/Game/Maps/NaiSarak','-stage','-pak','-iostore','-prereqs','-archive',"-archivedirectory=$OutputDirectory",'-utf8output')
$game = @(Get-ChildItem $OutputDirectory -Filter 'NewDelhiUnderworld.exe' -Recurse)
if ($game.Count -eq 0) { throw 'Packaging returned without the expected game executable. Inspect the UAT log.' }
Write-Host "Packaged game: $($game[0].FullName)"
Write-Host 'Share the entire packaged Windows directory, including its Content and Engine folders.'
