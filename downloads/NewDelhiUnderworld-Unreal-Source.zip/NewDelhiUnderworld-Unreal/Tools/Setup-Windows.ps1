param([string]$EngineRoot, [switch]$OpenEditor)
. "$PSScriptRoot\Unreal-Windows.ps1"
$engine = Resolve-UnrealEngine $EngineRoot
$projectRoot = Split-Path $PSScriptRoot -Parent
$project = Join-Path $projectRoot 'NewDelhiUnderworld.uproject'
Write-Host "Building native editor module using $engine"
Invoke-UnrealChecked (Join-Path $engine 'Engine\Build\BatchFiles\Build.bat') @('NewDelhiUnderworldEditor','Win64','Development',"-Project=$project",'-WaitMutex','-NoHotReloadFromIDE')
Write-Host 'Editor module built. Import and configure your art assets using Docs/ART-SETUP.md.'
if ($OpenEditor) { Start-Process (Join-Path $engine 'Engine\Binaries\Win64\UnrealEditor.exe') -ArgumentList ('"{0}"' -f $project) }
