"""Engine-independent validation. Asset existence and compatibility are checked in UE."""
import math
import re


def validate(data):
    if not isinstance(data, dict) or data.get('version') != 1:
        raise ValueError('Art manifest must be an object with version 1.')
    for key in ('environment_map', 'player_blueprint', 'vehicle_blueprint', 'enemy_blueprint'):
        path = data.get(key)
        if not isinstance(path, str) or not re.fullmatch(r'/Game/[A-Za-z0-9_/]+', path):
            raise ValueError(f'{key}: provide an imported /Game/... asset package path, without an extension.')
    if data['environment_map'] == '/Game/Maps/NaiSarak':
        raise ValueError('environment_map must be the source environment, not the output mission map.')
    positions = data.get('positions', {})
    if not isinstance(positions, dict):
        raise ValueError('positions must be an object.')
    for key in ('player', 'car', 'contact', 'ledger', 'delivery'):
        point(positions.get(key), f'positions.{key}')
    enemies = data.get('enemies')
    if not isinstance(enemies, list) or not 1 <= len(enemies) <= 20:
        raise ValueError('Place between 1 and 20 guards with unique IDs.')
    ids = set()
    for enemy in enemies:
        if not isinstance(enemy, dict):
            raise ValueError('Each enemy must be an object.')
        name = enemy.get('id')
        if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}', name) or name.lower() in ids:
            raise ValueError('Guard IDs must be unique (case-insensitive) simple names.')
        ids.add(name.lower())
        point(enemy.get('position'), f'enemy {name}')
    return data


def point(value, name):
    if not isinstance(value, list) or len(value) != 3 or any(type(v) not in (int, float) or not math.isfinite(v) or abs(v) >= 1_000_000 for v in value):
        raise ValueError(f'{name}: expected three finite coordinates in Unreal centimeters, inside +/- 1,000,000.')
