param([string]$EngineRoot)
. "$PSScriptRoot\Unreal-Windows.ps1"
$engine = Resolve-UnrealEngine $EngineRoot
$projectRoot = Split-Path $PSScriptRoot -Parent
$manifest = Join-Path $projectRoot 'Content\ArtManifest.json'
if (!(Test-Path $manifest)) { throw 'Create Content\ArtManifest.json following Docs/ART-SETUP.md first.' }
$project = Join-Path $projectRoot 'NewDelhiUnderworld.uproject'
$script = Join-Path $PSScriptRoot 'build_map.py'
# Render-capable editor commandlet: Lumen/physics still require an interactive playtest afterward.
Invoke-UnrealChecked (Join-Path $engine 'Engine\Binaries\Win64\UnrealEditor-Cmd.exe') @($project,'-run=pythonscript',"-script=$script",'-unattended','-nosplash','-stdout','-FullStdOutLogOutput')
if (!(Test-Path (Join-Path $projectRoot 'Content\Maps\NaiSarak.umap'))) { throw 'Map generation did not produce NaiSarak.umap.' }
Write-Host 'Mission map saved. Open /Game/Maps/NaiSarak in Unreal and run the acceptance checklist before packaging.'
