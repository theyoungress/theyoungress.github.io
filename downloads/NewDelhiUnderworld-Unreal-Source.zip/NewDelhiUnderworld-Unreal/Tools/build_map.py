"""Run only inside UE Editor after compiling the native module and importing art.
Duplicates a supplied authored environment; never creates substitute box geometry.
"""
import json
import os
import sys
import unreal

sys.path.insert(0, os.path.dirname(__file__))
from manifest import validate

root = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())
with open(os.path.join(root, 'Content', 'ArtManifest.json'), encoding='utf-8') as stream:
    manifest = validate(json.load(stream))
library = unreal.EditorAssetLibrary
output = '/Game/Maps/NaiSarak'
mode_path = '/Game/NewDelhi/BP_MissionGameMode'
if library.does_asset_exist(output) or library.does_asset_exist(mode_path):
    raise RuntimeError('Output map or game mode already exists. Back it up and rename it before generating a replacement.')
if not library.does_asset_exist(manifest['environment_map']):
    raise RuntimeError('The source environment map is not imported.')
classes = {}
for key, native in [('player_blueprint', unreal.NDPlayerCharacter), ('vehicle_blueprint', unreal.NDVehiclePawn), ('enemy_blueprint', unreal.NDEnemyCharacter)]:
    cls = library.load_blueprint_class(manifest[key])
    if cls is None:
        raise RuntimeError(f'{key}: cannot load Blueprint class.')
    obj = unreal.get_default_object(cls)
    if not isinstance(obj, native):
        raise RuntimeError(f'{key}: Blueprint must inherit {native.__name__}.')
    mesh = obj.get_component_by_class(unreal.SkeletalMeshComponent)
    if mesh is None or mesh.get_editor_property('skeletal_mesh') is None or mesh.get_editor_property('anim_class') is None:
        raise RuntimeError(f'{key}: assign both a real skeletal mesh and compatible animation Blueprint.')
    if key == 'vehicle_blueprint':
        if mesh.get_physics_asset() is None:
            raise RuntimeError('Vehicle needs a configured physics asset.')
        movement = obj.get_component_by_class(unreal.ChaosWheeledVehicleMovementComponent)
        wheels = movement.get_editor_property('wheel_setups')
        if len(wheels) != 4:
            raise RuntimeError('Configure four Chaos wheel setups for this vehicle.')
        for wheel in wheels:
            if mesh.get_bone_index(wheel.get_editor_property('bone_name')) < 0:
                raise RuntimeError('A configured vehicle wheel bone is absent from its skeletal mesh.')
    classes[key] = cls
# Validate the supplied environment before creating persistent outputs.
levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
if not levels.load_level(manifest['environment_map']):
    raise RuntimeError('Cannot open source environment map.')
existing = actors.get_all_level_actors()
if not any(isinstance(a, unreal.NavMeshBoundsVolume) for a in existing):
    raise RuntimeError('Source environment requires NavMeshBoundsVolume coverage over the mission area. Build navigation in the editor first.')
if any(isinstance(a, (unreal.NDMissionDirector, unreal.NDMissionPoint, unreal.NDEnemyCharacter, unreal.NDVehiclePawn)) for a in existing):
    raise RuntimeError('Source environment already contains mission actors. Use a clean authored environment.')
world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
if not unreal.EditorLoadingAndSavingUtils.save_map(world, output):
    raise RuntimeError('Could not save the mission copy of the environment map.')
factory = unreal.BlueprintFactory()
factory.set_editor_property('parent_class', unreal.NDGameMode)
mode = unreal.AssetToolsHelpers.get_asset_tools().create_asset('BP_MissionGameMode', '/Game/NewDelhi', unreal.Blueprint, factory)
if mode is None:
    raise RuntimeError('Could not create the mission game mode.')
unreal.BlueprintEditorLibrary.compile_blueprint(mode)
mode_class = library.load_blueprint_class(mode_path)
unreal.get_default_object(mode_class).set_editor_property('default_pawn_class', classes['player_blueprint'])
library.save_loaded_asset(mode)
world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
world.get_world_settings().set_editor_property('default_game_mode', mode_class)
for actor in actors.get_all_level_actors():
    if isinstance(actor, unreal.PlayerStart):
        actors.destroy_actor(actor)


def spawn(cls, position):
    actor = actors.spawn_actor_from_class(cls, unreal.Vector(*position))
    if actor is None:
        raise RuntimeError(f'Failed to place {cls} at {position}.')
    return actor


positions = manifest['positions']
spawn(unreal.PlayerStart, positions['player'])
spawn(classes['vehicle_blueprint'], positions['car'])
spawn(unreal.NDMissionDirector, positions['contact'])
for key, kind in [('contact', unreal.NDPointKind.CONTACT), ('ledger', unreal.NDPointKind.LEDGER), ('delivery', unreal.NDPointKind.DELIVERY)]:
    actor = spawn(unreal.NDMissionPoint, positions[key])
    actor.set_editor_property('kind', kind)
    actor.set_actor_label('Mission_' + key)
for row in manifest['enemies']:
    actor = spawn(classes['enemy_blueprint'], row['position'])
    actor.set_editor_property('save_id', row['id'])
    actor.set_actor_label(row['id'])
if not levels.save_current_level():
    raise RuntimeError('Could not save the populated mission map.')
unreal.log('Mission map created. Visual quality, navmesh, collision, animations, vehicle handling, and gameplay still require an editor playtest.')
