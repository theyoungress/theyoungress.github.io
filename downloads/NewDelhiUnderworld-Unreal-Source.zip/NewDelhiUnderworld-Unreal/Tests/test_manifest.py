import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Tools'))
from manifest import validate

class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.data = dict(version=1, environment_map='/Game/Art/Delhi', player_blueprint='/Game/Actors/Player', vehicle_blueprint='/Game/Actors/Car', enemy_blueprint='/Game/Actors/Guard', positions={k:[0,0,100] for k in ('player','car','contact','ledger','delivery')}, enemies=[dict(id='GuardA',position=[1,2,3])])
    def test_complete(self):
        self.assertEqual(validate(self.data), self.data)
    def test_missing_assets(self):
        self.data['player_blueprint']=''
        with self.assertRaises(ValueError): validate(self.data)
    def test_no_output_overwrite(self):
        self.data['environment_map']='/Game/Maps/NaiSarak'
        with self.assertRaises(ValueError): validate(self.data)
    def test_coordinate_rejection(self):
        for value in (float('nan'),float('inf'),1_000_000,True,'zero'):
            with self.subTest(value=value):
                data=copy.deepcopy(self.data); data['positions']['player']=[value,0,0]
                with self.assertRaises(ValueError): validate(data)
    def test_duplicate_ids_case_insensitive(self):
        self.data['enemies'].append(dict(id='guarda',position=[0,0,0]))
        with self.assertRaises(ValueError): validate(self.data)
    def test_missing_guards(self):
        self.data['enemies']=[]
        with self.assertRaises(ValueError): validate(self.data)
    def test_invalid_position_structure(self):
        self.data['positions']=[]
        with self.assertRaises(ValueError): validate(self.data)
    def test_missing_position(self):
        del self.data['positions']['delivery']
        with self.assertRaises(ValueError): validate(self.data)
    def test_invalid_version(self):
        self.data['version']=2
        with self.assertRaises(ValueError): validate(self.data)

if __name__=='__main__': unittest.main()
