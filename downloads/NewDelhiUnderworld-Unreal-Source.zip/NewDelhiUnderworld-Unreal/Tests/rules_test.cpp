#include "NDGameplayRules.h"
#include <iostream>
#include <limits>
int main() {
    int total=0, failed=0;
    auto check=[&](bool ok,const char* message){ ++total; if(!ok) ++failed; std::cout<<(ok?"PASS: ":"FAIL: ")<<message<<'\n'; };
    ND::State s;
    check(!ND::Advance(s,ND::Event::Deliver,{true,true,true,true}) && s.money==2500,"Delivery cannot skip mission");
    check(!ND::Advance(s,ND::Event::Talk,{false,true,false,true}),"Contact requires interaction range");
    check(ND::Advance(s,ND::Event::Talk,{true,false,false,true}) && s.stage==ND::Stage::Ledger,"Contact advances ledger objective");
    check(!ND::Advance(s,ND::Event::Recover,{true,false,false,true}),"Living guards block pickup");
    check(ND::Advance(s,ND::Event::Recover,{true,true,false,true}) && s.stage==ND::Stage::Vehicle,"Cleared encounter permits recovery");
    check(ND::Advance(s,ND::Event::EnterCar,{true,true,true,true}) && s.stage==ND::Stage::Delivery,"Vehicle entry starts delivery");
    check(!ND::Advance(s,ND::Event::Deliver,{true,true,true,false}),"Moving car cannot complete delivery");
    check(!ND::Advance(s,ND::Event::Deliver,{true,true,false,true}),"On-foot arrival cannot complete vehicle objective");
    check(ND::Advance(s,ND::Event::Deliver,{true,true,true,true}) && s.money==7500,"Stationary delivery pays reward");
    check(!ND::Advance(s,ND::Event::Deliver,{true,true,true,true}) && s.money==7500,"Reward cannot repeat");
    ND::State already_driving{ND::Stage::Ledger,2500};
    check(ND::Advance(already_driving,ND::Event::Recover,{true,true,true,true}) && already_driving.stage==ND::Stage::Delivery,"Recovery while driving cannot softlock mission");
    int magazine=2,reserve=20;
    check(ND::Reload(magazine,reserve)==10 && magazine==12 && reserve==10,"Reload conserves ammunition");
    magazine=5;reserve=2;
    check(ND::Reload(magazine,reserve)==2 && magazine==7 && reserve==0,"Low reserve causes partial reload");
    check(ND::Reload(magazine,reserve)==0 && magazine==7,"Empty reserve cannot create ammunition");
    check(!ND::ValidPosition(std::numeric_limits<double>::quiet_NaN(),0,0),"NaN save coordinates rejected");
    check(!ND::ValidPosition(0,std::numeric_limits<double>::infinity(),0),"Infinite save coordinates rejected");
    check(!ND::ValidPosition(1e15,0,0),"Out-of-world save coordinates rejected");
    std::cout<<"RESULT: "<<total-failed<<"/"<<total<<" engine-independent checks passed\n";
    return failed?1:0;
}
